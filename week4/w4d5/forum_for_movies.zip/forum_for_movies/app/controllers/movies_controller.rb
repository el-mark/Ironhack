require 'pry'
require 'imdb'

class MoviesController < ApplicationController
  def search_movie
    @movies = Movie.order(created_at: :desc).limit(10)
  end
  def search_result
    @search_movie = params[:search_movie]
    @movie_on_db = Movie.find_by('lower(title) = ?', params[:search_movie].downcase)
    if @movie_on_db != nil
      redirect_to movie_path(@movie_on_db.id)
    else
      movie_search = Imdb::Search.new(params[:search_movie])
      @movies = movie_search.movies[0..19]
    end
  end
  def show
    @movie = Movie.find_by(id: params[:id])
  end
  def save_movie
    @saved_movie = Imdb::Movie.new(params[:imdb_id])
    @movie_in_db = Movie.create title: @saved_movie.title, poster_url: @saved_movie.poster, year: @saved_movie.year, synopsis: @saved_movie.plot_synopsis
    redirect_to movie_path(@movie_in_db.id)
  end
end
